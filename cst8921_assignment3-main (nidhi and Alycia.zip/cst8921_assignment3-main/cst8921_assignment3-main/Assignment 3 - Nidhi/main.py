from flask import Flask, request, jsonify
from flask_socketio import SocketIO
from datetime import datetime
import threading
import time

TempMax = 50
SmokeMax = 300

fireDrill_mode = False
offline_timeout = 300

sensor_last_seen = {}

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, cors_allowed_origins="*")


@app.route('/toggle-fire-drill', methods=['POST'])
def toggle_fire_drill():
    global fireDrill_mode
    fireDrill_mode = not fireDrill_mode
    status = "ON" if fireDrill_mode else "OFF"
    return jsonify({"message": f"Fire drill mode is now {status}"}), 200


def monitor_sensor_activity():
    while True:
        now = datetime.now()
        for device_id, last_seen in list(sensor_last_seen.items()):
            elapsed = (now - last_seen).total_seconds()
            if elapsed > offline_timeout:
                socketio.emit('device_offline', {"device_id": device_id})
        time.sleep(60)


def handle_sensor_alert(device_id, temperature, smoke):
    timestamp = datetime.now().isoformat()

    sensor_last_seen[device_id] = datetime.now()

    alert_data = {
        'device_id': device_id,
        'temperature': temperature,
        'smoke': smoke,
        'timestamp': timestamp,
        'fire_drill': fireDrill_mode
    }

    if temperature > TempMax or smoke > SmokeMax:
        if fireDrill_mode:
            socketio.emit('fire_drill_alert', alert_data)
            print(f"Fire Drill Alert for {device_id} (NOT real).")
        else:
            socketio.emit('fire_alert', alert_data)
            print(f"REAL ALERT: Dispatching 911 for {device_id}!")
    else:
        socketio.emit('sensor_update', alert_data)


@app.route('/sensor-data', methods=['POST'])
def receive_data():
    data = request.get_json()
    device_id = data.get('device_id', 'unknown_device')
    temperature = data.get('temperature')
    smoke_level = data.get('smoke')

    if temperature is None or smoke_level is None:
        return jsonify({'error': 'Missing data'}), 400

    handle_sensor_alert(device_id, temperature, smoke_level)

    return jsonify({'status': 'received'}), 200


if __name__ == '__main__':
    threading.Thread(target=monitor_sensor_activity, daemon=True).start()
    socketio.run(app, host='0.0.0.0', port=5000)
